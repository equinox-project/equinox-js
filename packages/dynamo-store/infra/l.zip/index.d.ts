import { DynamoDBStreamHandler } from "aws-lambda";
import { DynamoStoreIngester } from "@equinox-js/dynamo-store-indexer";
export declare const ingester: DynamoStoreIngester;
export declare const handler: DynamoDBStreamHandler;

import { DynamoDBStreamEvent } from "aws-lambda";
import { DynamoStoreIndexer } from "@equinox-js/dynamo-store-indexer";
export declare const handle: (service: DynamoStoreIndexer, evt: DynamoDBStreamEvent["Records"]) => Promise<void>;
